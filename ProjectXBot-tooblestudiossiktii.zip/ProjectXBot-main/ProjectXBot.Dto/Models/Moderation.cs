﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#pragma warning disable CS8618 
namespace ProjectXBot.Models
{    
    public class ModerationModel
    {
        public string? Username { get; set; }
        public long? userId { get; set; }
        public string? Reason { get; set; }
        public string? AvatarUrl { get; set; }
        public bool? Issilent { get; set; }
        public ModerationType? ModType { get; set; }
        public bool? isSite { get; set; }
    }
}
