using Microsoft.AspNetCore.Mvc;
using DSharpPlus;
using DSharpPlus.Entities;
using Microsoft.AspNetCore.Mvc.Routing;
namespace ProjectXBot.Webserver.Controllers
{
    [ApiController]
    [Route("/")]
    public class ApplicationController : ControllerBase
    {
        [HttpGet("isuserinserver")]
        public async Task<dynamic> DiscordCheck(ulong discordId)
        {
            var guild = await Configuration.client.GetGuildAsync(Configuration.guildId);
            var member = await guild.GetMemberAsync(discordId);
            if (member == null) 
            {
                return new
                {
                    success = false,
                    username = false
                };
            }
            return new
            {
                success = true,
                username = member.Username
            };
        }
        [HttpGet("sendmsg")]
        public async void SendApplicationMessage(ulong discordId, string applicationId)
        {
            var guild = await Configuration.client.GetGuildAsync(Configuration.guildId);
            var member = await guild.GetMemberAsync(discordId);
            var embed = new DiscordEmbedBuilder();
            embed.Title = "Project X Application";
            embed.Color = DiscordColor.Red;
            embed.Description = $"An application was made with id: **{applicationId}**";
            embed.AddField("If you made this application", "You can ignore this message");
            embed.AddField("If you didn't **make** this application", "Please create a ticket in the Discord server with the application id");
            try
            {
                await member.SendMessageAsync(embed.Build());
            }
            catch (Exception)
            {
                Console.WriteLine("Couldn't DM user the dms are most likely off");
            }
        }
    }
}
