﻿using ProjectXBot.Dto.Models;
using System.Text.Json;
namespace ProjectXBot.Helper.PJXApi
{
    public class GamblingApi
    {
        public static async Task<Gambling> CoinFlip(string discordId, long amount)
        {
            //response =
            //wtf???????
            Gambling gamblingResponse = null;
            try
            {
                gamblingResponse = JsonSerializer.Deserialize<Gambling>(await httpClient._client.GetAsync($"bot/coinflip?discordId={discordId}&amount={amount}").Result.Content.ReadAsStringAsync());
            }
            catch (Exception e)
            {
                Console.WriteLine($"Something went really wrong: {e.Message}");
            }
            return gamblingResponse;
        }
    }
}
