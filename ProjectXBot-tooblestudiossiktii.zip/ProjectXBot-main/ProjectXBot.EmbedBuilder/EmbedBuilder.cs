﻿using DSharpPlus.Entities;
using ProjectXBot.Models;
using System.Globalization;
using ProjectXBot.Dto.Enums;
using ProjectXBot.Dto.Models;
using System.Drawing;
namespace ProjectXBot
{
    public static class EmbedBuilder
    {
        public static DiscordInteractionResponseBuilder ModerationEmbed(ModerationModel mod)
        {
            if (mod.Username == null)
                throw new ArgumentNullException(nameof(mod.Username));

            if (mod.AvatarUrl == null)
                throw new ArgumentNullException(nameof(mod.AvatarUrl));

            var embed = new DiscordEmbedBuilder
            {
                Color = DiscordColor.SpringGreen,
                Description = $"Reason: {mod.Reason ?? "No reason provided"}",
                Title = $"{mod.ModType} {mod.Username}",
                Thumbnail = new DiscordEmbedBuilder.EmbedThumbnail
                {
                    Url = mod.AvatarUrl,
                }
            };

            var builder = new DiscordInteractionResponseBuilder()
                .AddEmbed(embed)
                .AsEphemeral((bool)mod.Issilent);

            return builder;
        }
        public static DiscordInteractionResponseBuilder KickedUserFromGame(ModerationModel mod)
        {
            var embed = new DiscordEmbedBuilder
            {
                Color = DiscordColor.Red,
                Title = $"Kicked user with id {mod.userId}!",
            };

            var builder = new DiscordInteractionResponseBuilder()
                .AddEmbed(embed)
                .AsEphemeral(false);

            return builder;
        }
        public static DiscordEmbed MigoEmbed()
        {
            DiscordEmbed embed = new DiscordEmbedBuilder
            {
                Color = DiscordColor.SpringGreen,
                Description = $"MIGOOOOO",
                Title = "MIGO!",
                ImageUrl = "https://i.postimg.cc/9MHg9pBy/migo-1.webp"
            };

            return embed;
        }
        public static DiscordEmbed GamblingEmbed(Gambling gamblingresponse)
        {
            DiscordColor color = DiscordColor.Red;
            if (gamblingresponse.status == GamblingStatus.Won)
            {
                color = DiscordColor.Green;
            }
            DiscordEmbed embed = new DiscordEmbedBuilder
            {
                Title = "Coinflip",
                Description = gamblingresponse.message + gamblingresponse.submessage,
                Color = color,
            };
            return embed;
        }
        public static DiscordInteractionResponseBuilder UserBalanceEmbed(Balance balance, string mention, bool silent = false)
        {
            try
            {
                var embed = new DiscordEmbedBuilder
                {
                    Author = new DiscordEmbedBuilder.EmbedAuthor
                    {
                        Name = "Project X",
                    },
                    Title = "Balance",
                    Description = $"Showing balance for: {mention}",
                    Color = DiscordColor.Red,
                };
                var robux = int.Parse(balance.robux.ToString());
                var tickets = int.Parse(balance.tickets.ToString());
                embed.AddField("Robux", $"{robux:N0} R$", true);
                embed.AddField("Tickets", $"{tickets:N0}", true);

                var builder = new DiscordInteractionResponseBuilder()
                    .AddEmbed(embed)
                    .AsEphemeral(silent);

                return builder;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message.ToString());
                return null;
            }

        }
        public static DiscordInteractionResponseBuilder UserInfoEmbed(UserInfo userInfo, bool silent = false)
        {
            try
            {
                var embed = new DiscordEmbedBuilder
                {
                    Author = new DiscordEmbedBuilder.EmbedAuthor
                    {
                        Name = "Project X",
                    },
                    Title = userInfo.name,
                    Url = $"https://www.projex.zip/users/{userInfo.id}/profile",
                    Color = DiscordColor.Red,
                    ImageUrl = userInfo.imageUrl,
                };

                embed.AddField("Created", userInfo.created.ToString("D"), true);
                embed.AddField("ID", userInfo.id.ToString(), true);
                embed.AddField("Description", userInfo.description, false);
                embed.AddField("Is banned?", userInfo.isBanned ? "Yes" : "No", true);
                embed.AddField("RAP", userInfo.inventory_rap.ToString(CultureInfo.CurrentCulture), true);

                var builder = new DiscordInteractionResponseBuilder()
                    .AddEmbed(embed)
                    .AsEphemeral(silent);

                return builder;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message.ToString());
                return null;
            }

        }
        public static DiscordInteractionResponseBuilder AvatarEmbed(string avatarUrl, string username, bool silent = false)
        {
            var embed = new DiscordEmbedBuilder
            {
                Author = new DiscordEmbedBuilder.EmbedAuthor
                {
                    Name = username,
                    IconUrl = avatarUrl,
                },
                Title = $"{username}'s avatar",
                Color = DiscordColor.Red,
                ImageUrl = avatarUrl,
            };
            var builder = new DiscordInteractionResponseBuilder()
                .AddEmbed(embed)
                .AsEphemeral(silent);
            return builder;
        }
    }
}

