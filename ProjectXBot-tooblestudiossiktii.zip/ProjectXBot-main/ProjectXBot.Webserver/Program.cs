using DotNetEnv;
using DSharpPlus;
using DSharpPlus.SlashCommands;
using ProjectXBot.Modules;
using ProjectXBot.Webserver;
Env.Load();
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

var discord = new DiscordClient(new DiscordConfiguration()
{
    Token = Environment.GetEnvironmentVariable("token"),
    TokenType = TokenType.Bot,
    Intents = DiscordIntents.All
});
var slash = discord.UseSlashCommands();
// load all the modules
slash.RegisterCommands<PingModule>();
slash.RegisterCommands<ModerationModule>();
slash.RegisterCommands<FunModule>();
slash.RegisterCommands<PurgeModule>();
slash.RegisterCommands<UserModule>();
slash.RegisterCommands<DiscordLinkModule>();
slash.RegisterCommands<GamblingModule>();
//slash.RegisterCommands<OwnerModule>();
slash.RegisterCommands<ToolsModule>();

Configuration.client = discord;
Configuration.PJXApiKey = Environment.GetEnvironmentVariable("apikey");
Configuration.guildId = ulong.Parse(Environment.GetEnvironmentVariable("guildId"));
await discord.ConnectAsync();
app.UseAuthorization();

app.MapControllers();

app.Run();
