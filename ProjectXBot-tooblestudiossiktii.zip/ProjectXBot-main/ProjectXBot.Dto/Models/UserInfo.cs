﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#pragma warning disable CS8618 
namespace ProjectXBot.Models
{
    public class UserInfo
    {
        public long id { get; set; }
        public string name { get; set; }
        public string displayName { get; set; }
        public string? description { get; set; } 
        public DateTime created { get; set; }
        public bool isBanned { get; set; }
        public long inventory_rap { get; set;}
        public string imageUrl { get; set; }   
    }

    public class Balance
    {
        public string message { get; set; }
        public int robux { get; set; }
        public int tickets { get; set; }
    }
}
