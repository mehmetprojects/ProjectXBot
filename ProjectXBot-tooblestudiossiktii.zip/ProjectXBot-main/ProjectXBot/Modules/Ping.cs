﻿using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectXBot.Modules
{
    public class PingModule : ApplicationCommandModule
    {
        [SlashCommand("ping", "ping pong!")]
        public async Task Ping(InteractionContext ctx)
        {
            await ctx.CreateResponseAsync($"Pong! {ctx.Client.Ping}ms");
        }
    }
}
