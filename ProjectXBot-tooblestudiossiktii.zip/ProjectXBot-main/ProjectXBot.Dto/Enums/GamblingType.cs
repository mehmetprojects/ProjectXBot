﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectXBot.Dto.Enums
{
    public enum GamblingStatus
    {
        Won = 0,
        Lost,
        InsufficientBalance,
        InvalidAmount,
        UnknownError,
    }
}

