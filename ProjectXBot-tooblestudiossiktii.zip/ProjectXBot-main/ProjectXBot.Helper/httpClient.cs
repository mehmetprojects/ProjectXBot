﻿using ProjectXBot.Webserver;
using System;
using System.Net;
using System.Net.Http;

namespace ProjectXBot.Helper
{
    public static class httpClient
    {
        public static HttpClient _client { get; } = new HttpClient(new HttpClientHandler()
        {
            AutomaticDecompression = DecompressionMethods.All
        })
        {
            BaseAddress = new Uri("https://www.projex.zip")
        };

        static httpClient()
        {
            _client.DefaultRequestHeaders.Add("PJX-BOTAUTH", ProjectXBot.Webserver.Configuration.PJXApiKey);
            _client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
        }
    }
}
