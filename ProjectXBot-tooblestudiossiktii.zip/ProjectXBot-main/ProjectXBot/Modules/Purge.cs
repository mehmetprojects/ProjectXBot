﻿using DSharpPlus.SlashCommands;
using DSharpPlus;
using System.Threading.Tasks;
using DSharpPlus.Entities;
using System.Collections.Generic;
using System.Linq;
using ProjectXBot.Helper;

namespace ProjectXBot.Modules
{

    [GuildOnly]
    public class PurgeModule : ApplicationCommandModule
    {
        [SlashCommand("purge", "Clears the chat")]
        [SlashCommandPermissions(Permissions.ManageMessages)]
        public async Task PurgeAsync(InteractionContext ctx,
        [Option("amount", "Amount of messages that you wanted deleted")][Maximum(500)][Minimum(1)] long limit = 50,
        [Option("member", "Member to delete messages from")] DiscordUser? user = null)
        {
            await PurgeHelper.DeleteAsync(ctx, limit, null);
        }
    }

}
