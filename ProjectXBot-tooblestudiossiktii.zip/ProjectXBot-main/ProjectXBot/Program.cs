﻿using System;
using System.Threading.Tasks;
using DSharpPlus;
using DSharpPlus.SlashCommands;
using ProjectXBot.Modules;
using DSharpPlus.VoiceNext;
using DotNetEnv;
using ProjectXBot.Helper;
using ProjectXBot.Dto;
namespace ProjectXBot
{
    class Program
    {
        static void Main(string[] args)
        {
            Env.Load();
            MainAsync().GetAwaiter().GetResult();
        }
        static async Task MainAsync()
        {
            Configuration.DiscordToken = Environment.GetEnvironmentVariable("token");
            Configuration.PJXApiKey = Environment.GetEnvironmentVariable("apikey");
            var discord = new DiscordClient(new DiscordConfiguration()
            {
                Token = Configuration.DiscordToken,
                TokenType = TokenType.Bot,
                Intents = DiscordIntents.All
            });
            discord.UseVoiceNext(new VoiceNextConfiguration
            {
                AudioFormat = AudioFormat.Default 
            });
            var slash = discord.UseSlashCommands();
            // load all the modules
            slash.RegisterCommands<PingModule>();
            slash.RegisterCommands<ModerationModule>();
            slash.RegisterCommands<FunModule>();
            slash.RegisterCommands<PurgeModule>();
            slash.RegisterCommands<UserModule>();
            slash.RegisterCommands<DiscordLinkModule>();
            slash.RegisterCommands<OwnerModule>();
            slash.RegisterCommands<ToolsModule>();

            ulong ingameChannelId = 1317479756328996927;
            ulong onlineChannelId = 1317479756328996927;


            var url = "/bot/status"; 
            var interval = TimeSpan.FromMinutes(5);

            BackgroundJob.Start(discord, ingameChannelId, onlineChannelId, url, interval);
            await discord.ConnectAsync();
            await JoinVoiceChannelAsync(discord, 1317479756328996928, 1317479756328996928);
            await Task.Delay(-1);
        }

        static async Task JoinVoiceChannelAsync(DiscordClient client, ulong guildId, ulong channelId)
        {
            var guild = await client.GetGuildAsync(guildId);
            if (guild == null)
            {
                Console.WriteLine($"Could not find guild with ID {guildId}");
                return;
            }

            var channel = guild.GetChannel(channelId);
            if (channel == null)
            {
                Console.WriteLine($"Could not find channel with ID {channelId} in guild {guild.Name}");
                return;
            }

            var currentMember = guild.CurrentMember;
            if (currentMember == null)
            {
                Console.WriteLine($"Bot is not present in the guild {guild.Name}");
                return;
            }

            try
            {
                var vnc = await channel.ConnectAsync();
                if (vnc == null)
                {
                    Console.WriteLine("Failed to connect to the voice channel.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error connecting to the voice channel: {ex.Message}");
            }
        }
    }
}
