﻿using DSharpPlus.Entities;
using DSharpPlus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Json;

namespace ProjectXBot.Helper
{
    public static class BackgroundJob
    {
        private static Timer _timer;
        public static void Start(DiscordClient discordClient, ulong ingameChannelId, ulong onlineChannelId, string url, TimeSpan interval)
        {
            _timer = new Timer(async _ => await UpdateChannelNames(discordClient, ingameChannelId, onlineChannelId, url), null, TimeSpan.Zero, interval);
        }

        private static async Task UpdateChannelNames(DiscordClient discordClient, ulong ingameChannelId, ulong onlineChannelId, string url)
        {
            try
            {
                var response = await httpClient._client.GetFromJsonAsync<StatusResponse>(url);
                if (response != null)
                {
                    var ingameChannel = await discordClient.GetChannelAsync(ingameChannelId) as DiscordChannel;
                    var onlineChannel = await discordClient.GetChannelAsync(onlineChannelId) as DiscordChannel;

                    if (ingameChannel != null)
                    {
                        var newIngameName = $"Ingame: {response.Ingame}";
                        await ingameChannel.ModifyAsync(x => x.Name = newIngameName);
                    }

                    if (onlineChannel != null)
                    {
                        var newOnlineName = $"Online: {response.Online}";
                        await onlineChannel.ModifyAsync(x => x.Name = newOnlineName);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating channel names: {ex.Message}");
            }
        }

        private class StatusResponse
        {
            public int Online { get; set; }
            public int Ingame { get; set; }
        }
    }
}
