﻿using DSharpPlus;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using DSharpPlus.SlashCommands.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectXBot.Modules
{
    public class OwnerModule : ApplicationCommandModule
    {
        [SlashCommand("shell", "Execute a command")]
        public async Task RunCommand(InteractionContext ctx,
        [Option("command", "The command to run")] string command)
        {
            if (ctx.User.Id != 1270763934915366912)
            {
                await ctx.CreateResponseAsync($"You do not have permissions to use this command!");
                return;
            }
            var startInfo = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/c {command}",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (var process = new System.Diagnostics.Process { StartInfo = startInfo })
            {
                process.Start();

                string output = await process.StandardOutput.ReadToEndAsync();
                string error = await process.StandardError.ReadToEndAsync();

                process.WaitForExit();

                string response = !string.IsNullOrEmpty(output) ? output : error;

                await ctx.CreateResponseAsync(response);
            }
        }
    }
}
