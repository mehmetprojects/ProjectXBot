﻿using DSharpPlus;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using ProjectXBot.Models;
using System;
using System.Threading.Tasks;

namespace ProjectXBot.Helper
{
    public static class DiscordLinkHelper
    {
        public static async Task<string> GenerateLinkCode(string discordId)
        {
            string linkCode;
            var result = await httpClient._client.GetAsync($"/bot/generatecode?discordId={discordId}");
            Console.WriteLine(result.StatusCode);
            if (!result.IsSuccessStatusCode)
                throw new Exception("DiscordLinkGen error: " + result.StatusCode);
            var body = await result.Content.ReadAsStringAsync();
            linkCode = body.ToString();
            if (result.StatusCode == System.Net.HttpStatusCode.NoContent)
                linkCode = null;

            return linkCode;
        }
    }
}
