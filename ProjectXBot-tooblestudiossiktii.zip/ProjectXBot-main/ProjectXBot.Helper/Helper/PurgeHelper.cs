﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectXBot.Helper
{
    public static class PurgeHelper
    {
        public async static Task DeleteAsync(InteractionContext ctx, long limit, DiscordUser? user)
        {
            IEnumerable<DiscordMessage> messages = (await ctx.Channel.GetMessagesAsync((int)limit));
            if (user != null) 
            {
                messages = messages.Where(x => x.Author.Id == user.Id);
            }
            var deleteable = messages;
            deleteable = deleteable.Where(x => DateTimeOffset.Now.Subtract(x.CreationTimestamp).TotalDays < 14).ToList();

            if (!deleteable.Any())
            {
                await ctx.CreateResponseAsync("Couldn't find any messages.", true);
                return;
            }

            await ctx.Channel.DeleteMessagesAsync(deleteable, $"Purge requested by {ctx.User.Username}");
            await ctx.CreateResponseAsync($"Deleted {deleteable.Count()} messages", true);
        }
    }
}
