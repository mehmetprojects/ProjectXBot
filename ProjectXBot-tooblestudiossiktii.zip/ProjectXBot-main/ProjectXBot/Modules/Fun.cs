﻿using DSharpPlus.SlashCommands;
using DSharpPlus;
using DSharpPlus.Entities;
using System.Threading.Tasks;

namespace ProjectXBot.Modules
{
    public class FunModule : ApplicationCommandModule
    {
        [SlashCommand("migo", "Sends a picture of migo")]
        public async Task Migo(InteractionContext ctx)
        {
            await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, EmbedBuilder.MigoEmbed());
        }
    }
}
