﻿using DSharpPlus.SlashCommands;
using DSharpPlus.Entities;
using ProjectXBot;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectXBot.Modules
{
    [GuildOnly]
    public class ToolsModule : ApplicationCommandModule
    {
        [SlashCommand("avatar", "Get the avatar of a member")]
        public async Task GetAvatarAsync(InteractionContext ctx,
        [Option("member", "Member to get the avatar from")] DiscordUser user,
        [Option("silent", "Make the command hidden")] bool silent = false)
        {
            ctx.CreateResponseAsync(EmbedBuilder.AvatarEmbed(user.AvatarUrl, user.Username, silent));
        }
    }
}
