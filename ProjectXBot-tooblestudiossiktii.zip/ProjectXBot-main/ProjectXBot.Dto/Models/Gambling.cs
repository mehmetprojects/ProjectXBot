﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectXBot.Dto.Enums;
namespace ProjectXBot.Dto.Models
{
    public class Gambling
    {
        public string message { get; set; }
        public string? submessage { get; set; }
        public GamblingStatus status { get; set; }
    }

}
