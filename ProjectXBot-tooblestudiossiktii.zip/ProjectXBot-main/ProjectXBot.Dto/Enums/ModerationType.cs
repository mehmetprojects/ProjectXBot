﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectXBot.Models
{
    public enum ModerationType
    {
        Kicked = 1,
        Softbanned,
        Banned,
    }
}
