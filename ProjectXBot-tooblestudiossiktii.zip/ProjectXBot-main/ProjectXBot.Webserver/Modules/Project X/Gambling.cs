﻿using DSharpPlus.SlashCommands;
using ProjectXBot.Dto.Models;
using ProjectXBot.Dto.Enums;
using ProjectXBot.Helper.PJXApi;

namespace ProjectXBot.Modules
{
    public class GamblingModule : ApplicationCommandModule
    {
        [SlashCommand("coinflip", "Gamble your Robux")]
        public async Task Coinflip(InteractionContext ctx,
        [Option("amount", "You cannot bet more than 250 Robux.")] [Minimum(1)] [Maximum(250)] long amount,
        [Option("silent", "Make the command hidden")] bool silent = false)
        {
            Gambling gambling = null;
            try
            {
                gambling = await GamblingApi.CoinFlip(ctx.User.Id.ToString(), amount);
            }
            catch (Exception)
            {
                await ctx.CreateResponseAsync("An error has occured", true);
                return;
            }
            await ctx.CreateResponseAsync(EmbedBuilder.GamblingEmbed(gambling), silent);
        }
    }
}
