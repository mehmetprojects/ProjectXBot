﻿using System.Diagnostics;
using System.Net;
using System.Text.Json;
using ProjectXBot.Models;
namespace ProjectXBot.Helper
{
    public class UserApi
    {
        public static async Task<UserInfo> GetUserInfo(long? userId)
        {
            var result = await httpClient._client.GetAsync($"/apisite/users/v1/users/{userId}");
            if (!result.IsSuccessStatusCode)
                throw new Exception("Userinfo error: " + result.StatusCode);
            var body = await result.Content.ReadAsStringAsync();
            var imageUrlRaw = await httpClient._client.GetAsync($"/Thumbs/Avatar.ashx?userId={userId}");
            if(imageUrlRaw == null)
            {
                throw new Exception("Image url is null");
            }
            var finalUrl = imageUrlRaw.RequestMessage.RequestUri;
            UserInfo userInfo = JsonSerializer.Deserialize<UserInfo>(body);
            userInfo.imageUrl = finalUrl.ToString();
            if (string.IsNullOrEmpty(userInfo.description))
            {
                userInfo.description = "N/A";
            }

            return userInfo;
        }

        public static async Task<Balance> GetBalance(string discordId)
        {
            var result = await httpClient._client.GetAsync($"/bot/balance?discordId={discordId}");
            if (!result.IsSuccessStatusCode)
                throw new Exception("Balance error: " + result.StatusCode);
            var body = await result.Content.ReadAsStringAsync();
            if(body == null)
            {
                throw new NullReferenceException();
            };
            Balance balance = JsonSerializer.Deserialize<Balance>(body);

            return balance;
        }
    }
}