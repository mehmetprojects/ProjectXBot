﻿using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectXBot.Helper;
namespace ProjectXBot.Modules
{
    public class DiscordLinkModule : ApplicationCommandModule
    {
        [SlashCommand("linkaccount", "Link your Project X account to this bot!")]
        public async Task LinkAccount(InteractionContext ctx)
        {
            string linkCode = await DiscordLinkHelper.GenerateLinkCode(ctx.User.Id.ToString());
            if (linkCode == null)
            {
                await ctx.CreateResponseAsync("Your account is already linked to the Project X bot", ephemeral: true);
                return;
            }
            await ctx.CreateResponseAsync($"Your login URL is https://www.projex.zip/bot/verify?linkcode={linkCode}", ephemeral: true);
        }
    }
}
