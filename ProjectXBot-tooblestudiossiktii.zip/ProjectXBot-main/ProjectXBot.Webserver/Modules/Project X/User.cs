﻿using DSharpPlus.SlashCommands;
using DSharpPlus;
using System.Threading.Tasks;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands.Attributes;
using ProjectXBot.Helper;
using ProjectXBot.Models;
using System.Diagnostics.Metrics;
using System;

namespace ProjectXBot.Modules
{
    public class UserModule : ApplicationCommandModule
    {
        [SlashCommand("lookupuser", "Lookup a user with their username or their user id")]
        public async Task LookUpUser(InteractionContext ctx,
        [Option("id", "The user id of the person")] long? userId = null,
        [Option("silent", "Make the command hidden")] bool silent = false)
        {
            var userInfo = await UserApi.GetUserInfo(userId);
            Console.WriteLine(userInfo);
            await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource,
                EmbedBuilder.UserInfoEmbed(userInfo));
        }

        [SlashCommand("balance", "Get your balance")]
        public async Task GetBalance(InteractionContext ctx,
        [Option("silent", "Make the command hidden")] bool silent = false)
        {
            var balance = await UserApi.GetBalance(ctx.User.Id.ToString());
            if (balance.message == "User not found")
            {
                await ctx.CreateResponseAsync("Couldn't find user, is your discord account linked?");
                return;
            }
            if (balance.message == "An error occurred while retrieving user information")
            {
                await ctx.CreateResponseAsync("There was an unknown error while trying to fetch balance");
                return;
            }
            await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource,
                EmbedBuilder.UserBalanceEmbed(balance, ctx.User.Mention, silent));
        }
    }
}
