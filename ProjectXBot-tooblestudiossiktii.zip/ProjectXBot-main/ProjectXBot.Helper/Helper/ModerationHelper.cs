﻿using DSharpPlus;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using ProjectXBot.Models;
using System;
using System.Threading.Tasks;

namespace ProjectXBot.Helper
{
    public static class ModerationHelper
    {
        public static async Task PunishUser(InteractionContext ctx, ModerationType modtype, DiscordUser user, string? reason = null, bool silent = false)
        {
            try
            {
                var member = await ctx.Guild.GetMemberAsync(user.Id);
                if (member.Id == ctx.User.Id) 
                {
                    await ctx.CreateResponseAsync("You cannot punish yourself!", true);
                    return;
                }
                try
                {
                    var DMChannel = await member.CreateDmChannelAsync();
                    await DMChannel.SendMessageAsync($"You have been {modtype.ToString().ToLower()} from Project X for: {reason}");
                }
                catch (Exception)
                {

                }
                switch (modtype)
                {
                    case ModerationType.Kicked:
                        await member.RemoveAsync(reason: reason);
                        break;
                    //ban and insta unban
                    case ModerationType.Softbanned:
                        await member.BanAsync(7, reason: reason);
                        await member.UnbanAsync(reason: reason);
                        break;
                    case ModerationType.Banned:
                        await member.BanAsync(7, reason: reason);
                        break;
                }

                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource,
                    EmbedBuilder.ModerationEmbed(new ModerationModel
                    {
                        Username = member.Username,
                        Reason = reason,
                        AvatarUrl = member.AvatarUrl,
                        Issilent = silent,
                        ModType = modtype
                    }));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error banning user: {ex.Message}");
                await ctx.CreateResponseAsync($"An error occurred while trying to punish the user.", ephemeral: true);
            }
        }
        public static async Task KickUserFromGame(InteractionContext ctx, long userId)
        {
            var result = await httpClient._client.GetAsync($"/bot/kickuser?userId={userId}");
            if (!result.IsSuccessStatusCode)
            {
                await ctx.CreateResponseAsync("Failed to kick the user");
                return;
            }
            await ctx.CreateResponseAsync($"Kicked user with the ID: {userId}");
        }
    }
}
