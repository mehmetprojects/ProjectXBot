﻿using DSharpPlus;
namespace ProjectXBot.Webserver
{
    public static class Configuration
    {
        public static ulong guildId { get; set; }
        public static string PJXApiKey { get; set; }
        public static DiscordClient client { get; set; }
    }
}
