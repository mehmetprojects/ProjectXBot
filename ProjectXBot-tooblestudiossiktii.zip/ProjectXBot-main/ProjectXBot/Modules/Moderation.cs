﻿using DSharpPlus.CommandsNext.Attributes;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using DSharpPlus;
using System.Threading.Tasks;
using ProjectXBot.Models;
using ProjectXBot.Helper;
using DSharpPlus.SlashCommands.Attributes;

namespace ProjectXBot.Modules
{
    [GuildOnly]
    public class ModerationModule : ApplicationCommandModule
    {
        [SlashCommand("kick", "Kick a user")]
        [SlashRequirePermissions(Permissions.KickMembers)]
        public async Task Kick(InteractionContext ctx,
        [Option("user", "The user to kick")] DiscordUser user,
        [Option("reason", "The reason for the kick")] string? reason = null,
        [Option("slient", "Make the command hidden")] bool slient = false)
        {
            await ModerationHelper.PunishUser(ctx, ModerationType.Kicked, user, reason, slient);
        }

        [SlashCommand("softban", "Softban a user")]
        [SlashRequirePermissions(Permissions.BanMembers)]
        public async Task Softban(InteractionContext ctx,
        [Option("user", "The user to softban")] DiscordUser user,
        [Option("reason", "The reason for the softban")] string? reason = null,
        [Option("slient", "Make the command hidden")] bool slient = false)
        {
            await ModerationHelper.PunishUser(ctx, ModerationType.Softbanned, user, reason, slient);
        }

        [SlashCommand("ban", "Ban a user")]
        [SlashRequirePermissions(Permissions.BanMembers)]
        public async Task Ban(InteractionContext ctx,
        [Option("user", "The user to ban")] DiscordUser user,
        [Option("reason", "The reason for the ban")] string? reason = null,
        [Option("slient", "Make the command hidden")] bool slient = false)
        {
            await ModerationHelper.PunishUser(ctx, ModerationType.Banned, user, reason, slient);
        }
        
        [SlashCommand("kickgame", "Kick a user from a game")]
        [SlashRequirePermissions(Permissions.KickMembers)]
        public async Task Ban(InteractionContext ctx,
        [Option("user", "The id of the user to kick")] long userId)
        {
            await ModerationHelper.KickUserFromGame(ctx, userId);
        }
    }

}
